#include "Element.h"
#include "Cellule2.h"
#include "ListeCh2.h"
#include <stdlib.h>
#include <stdio.h>

void creerListe(ListeCh* pl)
{
    pl->courant = NULL;
    pl->debut = NULL;
    pl->fin=NULL;
}

int listeVide(ListeCh pl)
{
    return (pl.debut==NULL);
}

void inserer(ListeCh *pl, Element e)
{
    Cellule *c;
    c = (Cellule *) malloc(1*sizeof(Cellule));
    c->val = e;
    Cellule* savepos = c;
    pl->courant = savepos;
    printf("-1\n");

    if(listeVide(*pl))
    {
        //Pas de successeur + modif : debut, fin, courant
        c->suivant = NULL;
        c->precedant = NULL;
        pl->debut = c;
        pl->courant = c;
        pl->fin = c;
        printf("0\n");
    }
    else if(estDebut(*pl))
    {
        //Successeur & précédant : l'ancien premier + modif premier
        
        c->precedant = NULL;
        if(pl->courant->suivant != NULL)
        {
            c->suivant = pl->courant->suivant;
            pl->courant->precedant = c;
            printf("1\n");
        }
        else
        {
            c->suivant = NULL;
            printf("2\n");
        }
        c->precedant = pl->courant;
        pl->debut = c;
        pl->courant = c;
        printf("3\n");
    }
    else if(estFin(*pl))
    {
        //Pas de suivant Mais 1 précédant, modif fin + relier le dernier au nouveau
        pl->fin = c;

        c->suivant = NULL;
        pl->courant->suivant = c;
        c->precedant = pl->courant;
        printf("4\n");
    }
    else
    {
        //Relier les 2 autours
        c->precedant = pl->courant->precedant;
        c->suivant = pl->courant;
        pl->courant->precedant = c;
        pl->courant->precedant->suivant = c;
        printf("5\n");
    }

    pl->courant = savepos;
    printf("6\n");
}

void supprimer(ListeCh *pl)
{
    if (pl == NULL)
		return;

    Cellule* arriver = pl->courant->suivant;
	Cellule* aSave = pl->courant->precedant;

	if (pl->courant->precedant == NULL) { // 1er
		aSave = pl->courant->suivant;
		if (aSave != NULL)
            aSave->precedant = NULL;
		pl->courant = arriver;
	}
	else{ 
		aSave = pl->courant->precedant;
		aSave->suivant = pl->courant->suivant;
	}  

	if(pl->courant->suivant != NULL)
	{
		aSave = pl->courant->suivant;	
		aSave->precedant = pl->courant->precedant;
	}

	free(pl->courant);
    pl->courant = arriver;
}

Element valeurCourante(ListeCh l)
{
    return (l.courant->val);
}

void allerDebut(ListeCh *l)
{
    l->courant = l->debut;
}

void allerFin(ListeCh *pl)
{
    while( pl->courant->suivant != NULL)
        pl->courant = pl->courant->suivant;
    
    pl->fin = pl->courant;
}

void avancer(ListeCh *l)
{
    if(l->courant->suivant != NULL)
        l->courant = l->courant->suivant;
}

int estDebut(ListeCh l)
{
    printf("estDebut\n");
    return (l.debut == l.courant);
}

int estFin(ListeCh l)
{
    printf("estFin \n");
    return (l.fin == l.courant);
}
