#ifndef __ELEMENT_H__
#define __ELEMENT_H__

typedef int Element;

void saisie(Element* element);

void affichage(Element element);

#endif
