#include <stdio.h>
#include <stdlib.h>
#include "terme.h"

Terme Premier(void)
{

}

void afficher(Terme X)
{

}

Terme Suivant(Terme X)
{

}

double* stats(Terme X)
{

}

int coherent(double* tab)
{

}