#ifndef __ELEMENT_H__
#define __ELEMENT_H__

#include <stdlib.h>

typedef int Element;

Element SaisirElement(Element element);

void Affichage(Element element);

#endif // __ELEMENT_H__