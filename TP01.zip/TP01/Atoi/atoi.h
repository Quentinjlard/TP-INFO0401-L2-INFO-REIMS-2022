#ifndef _ATOI_H
#define _ATOI_H

int mon_atoi_a_moi(char * mot);

#endif